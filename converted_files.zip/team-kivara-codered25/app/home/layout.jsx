import "./globals.css";
import { Toaster } from "sonner";
import { ThemeProvider } from "next-themes";
import { Geist } from "next/font/google";

const geist = Geist({ subsets: ["latin"] });

export const metadata = {
	metadataBase: new URL("https://ai-sdk-preview-pdf-support.vercel.app"),
	title: "Code_red",
	description: "Experimental preview of PDF support with the AI SDK",
};

export default function RootLayout({ children }) {
	return (
		<html
			lang="en"
			suppressHydrationWarning
			className={`${geist.className}`}
		>
			<body>
				<ThemeProvider
					attribute="class"
					enableSystem
					forcedTheme="dark"
				>
					<Toaster position="top-center" richColors />
					{children}
				</ThemeProvider>
			</body>
		</html>
	);
}
